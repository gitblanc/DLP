/**
 * @generated VGen (for ANTLR) 1.7.1
 */

package ast;

public interface Sentence extends AST {

}
